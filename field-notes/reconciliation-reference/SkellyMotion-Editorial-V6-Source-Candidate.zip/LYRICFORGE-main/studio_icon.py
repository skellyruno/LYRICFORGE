"""Package the requested recolored original skull, verified by SHA256."""
from pathlib import Path
import hashlib,shutil
root=Path(__file__).resolve().parent/'static'
source=root/'skellyhub.ico'
if hashlib.sha256(source.read_bytes()).hexdigest()!='c472c19bbf94f3fdac172c1eeff7322d5e7dc2093e98cc095f2380a3e9bd82bb':raise RuntimeError('Brand icon checksum mismatch')
shutil.copyfile(source,root/'skull.ico')
