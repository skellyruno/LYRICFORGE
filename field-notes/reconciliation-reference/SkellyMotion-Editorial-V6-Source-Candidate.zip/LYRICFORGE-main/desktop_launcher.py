"""SkellyMotion desktop host: a native Windows window, no cmd or browser tab."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from multiprocessing import freeze_support

from desktop_watchdog import ConsecutiveFailureDetector, windows_ui_responding

WINDOW_TITLE = "SkellyMotion | Lyric video studio"
STUDIO_THEMES = ("neon", "obsidian", "amethyst", "crimson")


def read_studio_theme(home: Path) -> str:
    """Native localhost ports change at launch; store this outside the browser origin."""
    try:
        import json
        value = json.loads((home / "studio-theme.json").read_text(encoding="utf-8"))
        if value in STUDIO_THEMES:
            return value
    except (OSError, ValueError, TypeError):
        pass
    return "neon"



def initial_window_geometry(usable_width: int, usable_height: int) -> tuple[int, int, tuple[int, int]]:
    """Fit the native editor inside compact Windows working areas."""
    room_width = max(320, int(usable_width) - 24)
    room_height = max(240, int(usable_height) - 24)
    if 800 <= usable_width < 1200:
        room_width = min(room_width, max(800, int(usable_width * 0.84)))
    if 560 <= usable_height < 820:
        room_height = min(room_height, max(520, int(usable_height * 0.78)))
    width = min(960, room_width)
    height = min(623, room_height)
    return width, height, (min(800, width), min(520, height))


def native_work_area() -> tuple[int, int]:
    if sys.platform != "win32":
        return 1920, 1080
    try:
        import ctypes
        from ctypes import wintypes
        bounds = wintypes.RECT()
        if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(bounds), 0):
            width, height = int(bounds.right - bounds.left), int(bounds.bottom - bounds.top)
            if width > 0 and height > 0:
                return width, height
        width = int(ctypes.windll.user32.GetSystemMetrics(0))
        height = int(ctypes.windll.user32.GetSystemMetrics(1))
        if width > 0 and height > 0:
            return width, height
    except (AttributeError, OSError, TypeError, ValueError):
        pass
    return 1920, 1080


def runtime_dir() -> Path:
    return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))


def configure() -> Path:
    root = runtime_dir()
    tools = root / "tools"
    if tools.exists():
        os.environ["PATH"] = str(tools) + os.pathsep + os.environ.get("PATH", "")
    home = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "LyricForge"
    # Keep existing paths so older songs, corrected lyrics and the Whisper
    # model cache can be used with new builds without another download.
    os.environ.setdefault("LYRICFORGE_DATA", str(home / "workspace"))
    os.environ.setdefault("HF_HOME", str(home / "models"))
    os.environ.pop("LYRICFORGE_REQUIRE_AUTH", None)  # Local-only mode
    os.environ.setdefault("SKELLYMOTION_WATCH", "1")  # watch folders read local disk: desktop only
    home.mkdir(parents=True, exist_ok=True)
    # --windowed builds have no console streams; log errors instead of hiding them.
    if sys.stdout is None or sys.stderr is None:
        log_dir = home / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log = open(log_dir / "desktop.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = log
        sys.stderr = log
    return home


def native_error(message: str) -> None:
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, "SkellyMotion", 0x10)
    except Exception:
        print(message, file=sys.stderr)


def check_subtitle_renderer() -> None:
    """Actually render ASS into H.264; do not parse ffmpeg's filters listing."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg was not included in the app.")
    with tempfile.TemporaryDirectory(prefix="lyricforge-check-") as temp:
        root = Path(temp)
        ass = """[Script Info]
ScriptType: v4.00+
PlayResX: 320
PlayResY: 180
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,Arial,30,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,1,0,5,10,10,10,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.00,0:00:00.40,Main,,0,0,0,,SkellyMotion
"""
        (root / "check.ass").write_text(ass, encoding="utf-8-sig")
        child_flags = {"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}
        result = subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "color=c=black:s=320x180:r=25:d=0.3",
            "-vf", "ass=check.ass", "-frames:v", "3", "-c:v", "libx264",
            "-pix_fmt", "yuv420p", "check.mp4"], cwd=root,
            capture_output=True, text=True, timeout=45, **child_flags)
        if result.returncode or not (root / "check.mp4").exists():
            raise RuntimeError("FFmpeg cannot render lyrics: " + result.stderr[-500:])
        # A full portable smoke test must prove PyAV can probe what FFprobe
        # previously handled, including reading the compressed video stream.
        import server
        if not 0 < server.media_duration(root / "check.mp4") < 1:
            raise RuntimeError("Bundled PyAV could not read the rendered video duration")
        if server.video_stream_width(root / "check.mp4") != 320:
            raise RuntimeError("Bundled PyAV could not read the rendered video stream")


def self_test() -> int:
    import server
    assert server.STATIC.joinpath("index.html").is_file(), "Missing editor assets"
    check_subtitle_renderer()
    print("SkellyMotion portable self-test passed")
    return 0


def ai_self_test() -> int:
    """Validate the bundled offline Whisper inference engine without a model download.

    SkellyMotion passes vad_filter=False and does not require the optional
    Silero/ONNX runtime. Keep the real inference library and word-timestamp
    implementation present in the portable distribution.
    """
    from faster_whisper import WhisperModel
    from faster_whisper.vad import VadOptions
    from ctranslate2 import get_supported_compute_types
    import av
    assert callable(WhisperModel) and VadOptions is not None
    assert get_supported_compute_types("cpu")
    assert av.__version__
    print("SkellyMotion bundled Whisper/CTranslate2/PyAV import passed", flush=True)
    return 0


def bundled_python_runtime() -> Path:
    """The CLR bridge assembly that pythonnet loads."""
    return runtime_dir() / "pythonnet" / "runtime" / "Python.Runtime.dll"


# Narrow allowlist: only the managed assemblies SkellyMotion ships for its
# Python.NET / WebView2 window. Never touch every DLL or an entire folder.
MANAGED_UI_DLL_PATHS = (
    ("pythonnet", "runtime", "Python.Runtime.dll"),
    ("webview", "lib", "Microsoft.Web.WebView2.Core.dll"),
    ("webview", "lib", "Microsoft.Web.WebView2.WinForms.dll"),
    ("webview", "lib", "Microsoft.Web.WebView2.Wpf.dll"),
)


def bundled_managed_assemblies() -> list[Path]:
    root = runtime_dir().resolve()
    result = []
    for pieces in MANAGED_UI_DLL_PATHS:
        dll = root.joinpath(*pieces)
        # Don't follow a symlink to an untrusted location.
        if (dll.is_file() and not dll.is_symlink()
                and dll.resolve().is_relative_to(root)):
            result.append(dll)
    return result


def blocked_managed_assemblies() -> list[Path]:
    """Read Windows Mark-of-the-Web ADS on the exact bundled DLL allowlist."""
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return []
    marked = []
    for dll in bundled_managed_assemblies():
        try:
            with open(str(dll) + ":Zone.Identifier", "r",
                      encoding="utf-8", errors="replace") as stream:
                marker = stream.read(1024)
        except OSError:
            continue
        if any(token in marker for token in ("ZoneId=3", "ZoneId=4")):
            marked.append(dll)
    return marked


def native_runtime_self_test() -> int:
    """Smoke-test the EXACT .NET assemblies used by the native Windows editor.

    The previous test imported clr alone, allowing a working Python.NET loader
    but a broken/blocked Microsoft.Web.WebView2.Core.dll to slip through.
    """
    python_runtime = bundled_python_runtime()
    if getattr(sys, "frozen", False) and not python_runtime.is_file():
        raise RuntimeError("Missing Python.NET runtime: " + str(python_runtime))
    import clr
    from System import Environment
    if not Environment.Version:
        raise RuntimeError("The .NET bridge did not initialize")
    if getattr(sys, "frozen", False):
        root = runtime_dir()
        for name in ("Microsoft.Web.WebView2.Core.dll",
                     "Microsoft.Web.WebView2.WinForms.dll"):
            path = root / "webview" / "lib" / name
            if not path.is_file():
                raise RuntimeError("Missing bundled WebView2 managed assembly: " + str(path))
            # Load using the same full-path assembly resolution as pywebview.
            clr.AddReference(str(path))
            print("Verified native .NET assembly: " + name, flush=True)
    print("SkellyMotion Python.NET + WebView2 assembly self-test passed")
    return 0


def native_notice(message: str, error: bool = False) -> None:
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(
            None, message, "SkellyMotion - Windows runtime repair",
            0x10 if error else 0x40)
    except Exception:
        print(message, file=sys.stderr)


def offer_download_marker_repair() -> bool:
    """Offer one explicitly approved, narrowly scoped UI-DLL repair.

    Windows Explorer may propagate Mark-of-the-Web from the downloaded ZIP to
    multiple bundled .NET assemblies. Unblocking only Python.Runtime.dll then
    exposes a second 0x80131515 failure in Microsoft.Web.WebView2.Core.dll.
    """
    marked = blocked_managed_assemblies()
    if not marked:
        return False
    import ctypes
    names = "\n".join("  - " + item.name for item in marked)
    response = ctypes.windll.user32.MessageBoxW(
        None,
        "Windows marked these SkellyMotion UI libraries as downloaded:\n\n"
        + names
        + "\n\nOnly continue if this build came from your trusted "
          "SkellyMotion GitHub repository.\n\n"
          "Remove the Windows download markers from these "
          + str(len(marked)) + " files ONLY and continue?",
        "SkellyMotion - Repair blocked UI libraries",
        0x04 | 0x30,  # MB_YESNO | MB_ICONWARNING
    )
    if response != 6:  # IDYES
        print("User declined downloaded-DLL repair", file=sys.stderr)
        return False
    repaired = []
    for dll in marked:
        try:
            # Only deletes the file's Zone.Identifier alternate data stream,
            # NOT the DLL. The rest of Windows attachment protection remains.
            os.remove(str(dll) + ":Zone.Identifier")
            repaired.append(dll.name)
        except OSError as exc:
            print("Could not remove download marker from", dll.name, ":", exc,
                  file=sys.stderr)
    if repaired:
        print("User approved unblocking bundled UI DLLs:", ", ".join(repaired),
              file=sys.stderr)
    return len(repaired) == len(marked)


def desktop_runtime_error(exc: Exception) -> str:
    details = str(exc)
    if (any(token in details for token in
            ("0x80131515", "network location", "Microsoft.Web.WebView2",
             "Python.Runtime.Loader.Initialize", "Python.Runtime.dll"))):
        return (
            "SkellyMotion could not load one of its bundled .NET UI libraries.\n\n"
            "This can happen when Windows marks DLLs extracted from a download "
            "as untrusted, or when the app was not extracted completely.\n\n"
            "If you trust the GitHub build, run Repair-SkellyMotion.cmd "
            "beside SkellyMotion.exe to check the Python.NET and WebView2 "
            "UI DLLs. The repair asks before changing any download markers.\n\n"
            "Alternatively: right-click the downloaded ZIP > Properties > "
            "Unblock (if shown), then extract the ZIP again into a new folder.\n\n"
            "Details: " + details[:900]
        )
    return (
        "SkellyMotion couldn't open its desktop window.\n\n" + details[:900]
        + "\n\nCheck the desktop.log file. Install Microsoft Edge WebView2 "
          "Runtime only if the log indicates that WebView2 itself is missing."
    )


def available_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_until_ready(port: int, server_thread: threading.Thread, timeout: float = 15) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not server_thread.is_alive():
            return False
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.25):
                return True
        except OSError:
            time.sleep(0.12)
    return False



class DesktopFilePicker:
    """Native dialogs for the desktop only. The web site never receives file paths."""

    def __init__(self, home: Path | None = None):
        self._appearance_home = home
        self._appearance_lock = threading.Lock()
        # pywebview enumerates public js_api attributes recursively. A public
        # 'window' exposed the entire WinForms/WebView2 object graph (including
        # AccessibilityObject.Bounds.Empty...), causing massive recursion and
        # startup stalls. Keep native objects private to Python.
        self._window = None
        self.active_project = False
        self.allow_close = False
        self._saving_video = threading.Lock()
        self._close_pending = threading.Lock()
        self._selected_audio = None

    def set_studio_theme(self, theme):
        if not isinstance(theme, str) or theme not in STUDIO_THEMES:
            raise ValueError("Unsupported studio theme")
        if self._appearance_home is None:
            return {"saved": False}
        from studio_performance import atomic_write_json
        with self._appearance_lock:
            atomic_write_json(self._appearance_home / "studio-theme.json", theme)
        return {"saved": True}

    def session_active(self, active):
        self.active_project = bool(active)
        return {"active": self.active_project}

    def cancel_close(self):
        if self._close_pending.locked():
            try:
                self._close_pending.release()
            except RuntimeError:
                pass
        return True

    def approve_close(self):
        self.allow_close = True
        self.cancel_close()
        if self._window is not None:
            self._window.destroy()
        return True

    def save_video(self, project_id, preview=False):
        """Native Save As copies the MP4; it does not navigate the WebView.

        The no-wait lock prevents double-clicks from launching multiple huge
        simultaneous downloads and makes cancellation a no-op.
        """
        if not self._saving_video.acquire(blocking=False):
            return {"status": "busy"}
        try:
            import webview
            import server
            import re
            project = server.read_project(project_id)
            source = server.project_dir(project_id) / (
                "lyric_preview.mp4" if bool(preview) else "lyric_video.mp4")
            if not source.is_file() or source.stat().st_size < 1024:
                raise RuntimeError("The MP4 has not finished rendering yet.")
            title = re.sub(r"[^\w .()-]", "_", str(project.get("title") or "video"))[:55].strip(" .")
            filename = ("SkellyMotion-" + (title or "video") +
                        ("-preview" if preview else "") + ".mp4")
            dialog = getattr(getattr(webview, "FileDialog", None), "SAVE",
                             getattr(webview, "SAVE_DIALOG", 20))
            picked = self._window.create_file_dialog(
                dialog_type=dialog, save_filename=filename,
                file_types=("MP4 video (*.mp4)",))
            if not picked:
                return {"status": "cancelled"}
            target = Path(picked[0])
            if target.suffix.lower() != ".mp4":
                target = target.with_suffix(".mp4")
            if source.resolve() == target.resolve():
                return {"status": "saved", "path": str(target)}
            # Atomic replacement avoids leaving a partial copy if interrupted.
            temporary = target.with_name(target.name + ".part")
            try:
                with source.open("rb") as inp, temporary.open("wb") as out:
                    shutil.copyfileobj(inp, out, 1024 * 1024)
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
            return {"status": "saved", "path": str(target)}
        finally:
            self._saving_video.release()

    def _open_file(self, formats):
        import webview
        if self._window is None:
            raise RuntimeError("The SkellyMotion desktop window is not ready")
        # pywebview v5/v6 use FileDialog.OPEN; support older OPEN_DIALOG too.
        dialog = getattr(getattr(webview, "FileDialog", None), "OPEN",
                         getattr(webview, "OPEN_DIALOG", 10))
        picked = self._window.create_file_dialog(
            dialog_type=dialog, allow_multiple=False, file_types=(formats,))
        return Path(picked[0]) if picked else None

    def pick_audio_file(self):
        """Select a file without creating any project until Save/Discard is chosen."""
        self._selected_audio = self._open_file(
            "Music files (*.mp3;*.wav;*.flac;*.m4a;*.aac;*.ogg;*.opus;*.mp4;*.webm)")
        return {"chosen": True, "name": self._selected_audio.stem} if self._selected_audio else None

    def import_picked_audio(self, recognition="balanced", language="auto",
                            vocabulary="", performance_mode="balanced"):
        source, self._selected_audio = self._selected_audio, None
        if source is None or not source.is_file():
            raise RuntimeError("Choose an audio file before importing it")
        import server
        return server.import_desktop_audio_file(source, recognition, language,
                                                vocabulary, performance_mode)

    def choose_audio(self, recognition="balanced", language="auto",
                     vocabulary="", performance_mode="balanced"):
        """Legacy bridge supported for older JS clients."""
        picked = self.pick_audio_file()
        if not picked:
            return None
        return self.import_picked_audio(recognition, language, vocabulary, performance_mode)

    def choose_background(self, project_id):
        if not isinstance(project_id, str):
            raise ValueError("Choose a song before importing a background")
        source = self._open_file(
            "Images and video (*.jpg;*.jpeg;*.png;*.webp;*.mp4;*.mov;*.webm)")
        if source is None:
            return None
        import server
        return server.import_desktop_background_file(project_id, source)


def run_desktop(home: Path, safe_mode: bool = False,
                smoke_test: bool = False) -> int:
    started = time.monotonic()
    if safe_mode:
        # Opt-in diagnostic only. Normal WebView2 keeps GPU acceleration.
        flags = os.environ.get("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "")
        os.environ["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = (
            flags + " --disable-gpu --disable-gpu-compositing").strip()
    profile = home / ("webview_safe" if safe_mode else "webview")
    profile.mkdir(parents=True, exist_ok=True)

    def log_stage(stage: str) -> None:
        # Startup diagnostics let us distinguish Python import delay from
        # WebView2 initialization or project-level media loading.
        print(f"[startup] {stage}: {time.monotonic() - started:.2f}s",
              file=sys.stderr, flush=True)

    log_stage("begin" + (" (safe WebView2 profile, software rendering)" if safe_mode else ""))
    log_stage("user data folder: " + str(profile))
    if offer_download_marker_repair():
        log_stage("user approved bundled CLR DLL download-marker repair")
    import uvicorn
    log_stage("uvicorn imported")
    import server
    log_stage("local API loaded (Whisper model remains lazy)")
    import webview
    log_stage("native WebView module imported")

    port = available_port()
    config = uvicorn.Config(server.app, host="127.0.0.1", port=port,
                            log_level="warning", access_log=False)
    api_server = uvicorn.Server(config)
    worker = threading.Thread(target=api_server.run, name="SkellyMotionAPI", daemon=True)
    worker.start()
    if not wait_until_ready(port, worker):
        raise RuntimeError("The local editor server did not start. See desktop.log in " + str(home / "logs"))
    log_stage("API accepting connections")

    smoke_loaded = threading.Event()
    shown_event = threading.Event()
    monitor_stop = threading.Event()
    monitor_worker = None
    watchdog = None
    if smoke_test:
        # The packaged GUI must open, render and exit cleanly in CI.
        # A blocked native window cannot stall GitHub Actions indefinitely.
        def expired():
            print("[window-smoke] TIMEOUT: editor window did not close",
                  file=sys.stderr, flush=True)
            os._exit(4)
        # A cold WebView2 startup can spend 20-30s loading on CI before the
        # extended 10s liveness probes even begin. Bound the whole test,
        # but do not mistake slow initialization for a dead UI.
        watchdog = threading.Timer(95, expired)
        watchdog.daemon = True
        watchdog.start()

    try:
        picker = DesktopFilePicker(home)
        window_width, window_height, min_window = initial_window_geometry(*native_work_area())
        log_stage(f"initial editor window {window_width}x{window_height}, minimum {min_window}")
        window = webview.create_window(WINDOW_TITLE,
                              "http://127.0.0.1:" + str(port) + "/?desktop=1&theme=" + read_studio_theme(home),
                              width=window_width, height=window_height, min_size=min_window,
                              resizable=True, background_color="#090c0c",
                              js_api=picker)
        picker._window = window
        try:
            def on_closing():
                # Never block the native UI thread waiting for JavaScript.
                if picker.allow_close or smoke_test or not picker.active_project:
                    return True
                if not picker._close_pending.acquire(blocking=False):
                    return False
                def request_decision():
                    try:
                        delivered = window.evaluate_js(
                            "Boolean(window.SkellyBridge) && window.dispatchEvent(new Event('skellymotion-close-request'))")
                        if delivered is not True:
                            raise RuntimeError("Editor close bridge is not ready")
                    except Exception as exc:
                        log_stage("Could not show Save / Don't Save / Cancel: " + str(exc))
                        # Never silently discard the current project if the JS
                        # bridge is unavailable. Explicitly offer recovery-only exit.
                        try:
                            import ctypes
                            answer = ctypes.windll.user32.MessageBoxW(
                                None, "The editor could not open its Save dialog. Close and keep the last stored recovery? Recent unflushed edits may be lost.",
                                "SkellyMotion — close", 0x04 | 0x30 | 0x40000)
                            if answer == 6:
                                picker.approve_close()
                        except Exception as fallback_error:
                            log_stage("Native close dialog unavailable: " + str(fallback_error))
                        finally:
                            picker.cancel_close()
                threading.Thread(target=request_decision, daemon=True).start()
                return False
            window.events.closing += on_closing
            def on_shown():
                log_stage("native window shown")
                shown_event.set()
            window.events.shown += on_shown
            def on_loaded():
                log_stage("editor document loaded")
                if smoke_test and not smoke_loaded.is_set():
                    smoke_loaded.set()
                    def check_window_and_close():
                        # The old test sampled IsHungAppWindow only once, after
                        # four seconds. That missed freezes appearing later.
                        for attempt in range(6):
                            if windows_ui_responding(WINDOW_TITLE, 1300) is not True:
                                print("[window-smoke] UI message pump not responding "
                                      f"(probe {attempt + 1}/6)",
                                      file=sys.stderr, flush=True)
                                os._exit(5)
                            time.sleep(1.3)
                        # Exercise the renderer and Python.NET JavaScript bridge,
                        # not merely its ability to display a stale welcome page.
                        result: dict = {}
                        def check_dom():
                            try:
                                result["ready"] = window.evaluate_js(
                                    "Boolean(document.getElementById('heroUpload') "
                                    "&& document.getElementById('previewCanvas') "
                                    "&& document.getElementById('timelineInner'))")
                            except Exception as exc:
                                result["error"] = repr(exc)
                        check = threading.Thread(target=check_dom, daemon=True)
                        check.start()
                        check.join(timeout=6)
                        if check.is_alive() or result.get("ready") is not True:
                            print("[window-smoke] JavaScript renderer did not reply: "
                                  + str(result), file=sys.stderr, flush=True)
                            os._exit(6)
                        # Real WebView2 interaction, not a static stylesheet assertion.
                        theme_result = {}
                        def check_themes():
                            try:
                                theme_result["ok"] = window.evaluate_js(
                                    "(function(){const b=document.getElementById('studioTheme');"
                                    "if(!b)return false;const root=document.documentElement;"
                                    "const original=root.dataset.studioTheme;const seen=new Set();"
                                    "const accents=new Set();for(let i=0;i<4;i++){b.click();"
                                    "seen.add(root.dataset.studioTheme);"
                                    "accents.add(getComputedStyle(root).getPropertyValue('--accent').trim());}"
                                    "return seen.size===4&&accents.size===4&&root.dataset.studioTheme===original;})()")
                            except Exception as exc:
                                theme_result["error"] = repr(exc)
                        theme_check = threading.Thread(target=check_themes, daemon=True)
                        theme_check.start()
                        theme_check.join(timeout=8)
                        if theme_check.is_alive() or theme_result.get("ok") is not True:
                            print("[window-smoke] Theme interaction failed: " + str(theme_result), file=sys.stderr, flush=True)
                            os._exit(8)
                        log_stage("Four studio themes passed actual WebView2 interaction")
                        # Resize the actual WinForms/WebView2 application,
                        # not mocked elements, to catch compact-layout freezes.
                        for size in ((800, 520), (960, 623), (1024, 720)):
                            window.resize(*size)
                            time.sleep(0.4)
                            layout: dict = {}
                            def check_layout():
                                try:
                                    layout["ok"] = window.evaluate_js(
                                        "(function(){"
                                        "const app=document.querySelector('.app');"
                                        "const timeline=document.getElementById('timelineScroll');"
                                        "const welcome=document.getElementById('welcome');"
                                        "const shell=document.getElementById('studioShell');"
                                        "const exp=document.getElementById('topExport');"
                                        "if(!app||!timeline||!welcome||!shell||!exp)return false;"
                                        "const e=exp.getBoundingClientRect(),b=app.getBoundingClientRect();"
                                        "return Number.isFinite(b.width)&&Number.isFinite(b.height)"
                                        "&&b.width>200&&b.height>160"
                                        "&&Math.abs(b.width-innerWidth)<4&&Math.abs(b.height-innerHeight)<4"
                                        "&&e.right<=innerWidth+2&&e.left>=0&&e.top>=0"
                                        "&&timeline.getBoundingClientRect().height>20"
                                        "&&getComputedStyle(welcome).overflowY!=='hidden';"
                                        "})()")
                                except Exception as exc:
                                    layout["error"] = repr(exc)
                            probe = threading.Thread(target=check_layout, daemon=True)
                            probe.start()
                            probe.join(timeout=6)
                            if (probe.is_alive() or layout.get("ok") is not True
                                    or windows_ui_responding(WINDOW_TITLE, 1500) is not True):
                                print("[window-smoke] UI/layout failed at "
                                      + str(size) + ": " + str(layout),
                                      file=sys.stderr, flush=True)
                                os._exit(7)
                        log_stage("UI message pump, JavaScript and 3 window sizes "
                                  "passed repeated smoke probes")
                        window.destroy()
                    timer = threading.Timer(2, check_window_and_close)
                    timer.daemon = True
                    timer.start()
            window.events.loaded += on_loaded
        except (AttributeError, TypeError) as exc:
            log_stage("window event hooks unavailable: " + str(exc))
        def monitor_startup_window():
            # This is an independent Windows worker, never a WebView2/WinForms
            # callback. GUI liveness needs to be measured on the user's PC.
            if not shown_event.wait(35):
                if not monitor_stop.is_set():
                    log_stage("native window did not emit shown event")
                return
            detector = ConsecutiveFailureDetector(threshold=3)
            deadline = time.monotonic() + 100
            while time.monotonic() < deadline:
                if monitor_stop.wait(3):
                    return
                response = windows_ui_responding(WINDOW_TITLE, timeout_ms=1200)
                if not detector.observe(response):
                    continue
                log_stage("HANG DETECTED: 3 native UI message probes timed out")
                if picker.active_project or picker._selected_audio is not None:
                    # Do not kill an editing session or discard work.
                    log_stage("Active project/import: manual recovery required")
                    return
                target_mode = "--browser-mode" if safe_mode else "--safe-mode"
                description = ("Browser Mode" if safe_mode else "Safe Mode")
                try:
                    import ctypes
                    answer = ctypes.windll.user32.MessageBoxW(
                        None,
                        "SkellyMotion's Windows window has stopped responding. "
                        "The local editor may still be available.\n\n"
                        "Restart in " + description + "?\n\n"
                        "Your saved songs, projects and AI model will be kept. "
                        "Choose No to keep the current window and inspect "
                        "the desktop.log diagnostics.",
                        "SkellyMotion - Window not responding",
                        0x04 | 0x30 | 0x40000,  # Yes/No, warning, topmost
                    )
                    if answer != 6:
                        log_stage("user declined automatic fallback")
                        return
                    if getattr(sys, "frozen", False):
                        cmd = [sys.executable, target_mode]
                    else:
                        cmd = [sys.executable, str(Path(__file__).resolve()), target_mode]
                    subprocess.Popen(
                        cmd, cwd=str(Path(sys.executable).parent),
                        **({"creationflags": subprocess.CREATE_NO_WINDOW}
                           if os.name == "nt" else {}),
                    )
                    log_stage("launching " + description + " after startup hang")
                    # The WinForms UI thread is stuck and cannot exit normally.
                    # This is only reached after the user agrees AND when no
                    # project is active; otherwise preserve the running process.
                    os._exit(9)
                except Exception as exc:
                    log_stage("could not launch fallback: " + repr(exc))
                return

        if os.name == "nt" and not smoke_test:
            monitor_worker = threading.Thread(
                target=monitor_startup_window,
                name="SkellyMotionUIHangMonitor", daemon=True)
            monitor_worker.start()
        log_stage("native window created; initializing WebView2")
        # pywebview versions differ in support for native icon overrides.
        # The packaged EXE always embeds the skull icon.
        from inspect import signature
        options = {"icon": str(runtime_dir() / "static" / "skull.ico")} if "icon" in signature(webview.start).parameters else {}
        webview.start(gui="edgechromium", debug=False, private_mode=False,
                      storage_path=str(profile), **options)
    finally:
        monitor_stop.set()
        if watchdog is not None:
            watchdog.cancel()
        log_stage("native window closed or initialization ended")
        api_server.should_exit = True
        worker.join(timeout=5)
    if smoke_test and not smoke_loaded.is_set():
        raise RuntimeError("Packaged WebView2 editor never finished loading")
    return 0



def run_browser_mode(home: Path) -> int:
    """Use the same local studio without Python.NET/WebView2 window hosting.

    Fallback is intentionally user-initiated. The visible exit dialog keeps
    the local API alive and lets the user shut it down cleanly.
    """
    import uvicorn
    import server
    import webbrowser
    port = available_port()
    config = uvicorn.Config(server.app, host="127.0.0.1", port=port,
                            log_level="warning", access_log=False)
    instance = uvicorn.Server(config)
    thread = threading.Thread(target=instance.run, name="SkellyMotionBrowserAPI",
                              daemon=True)
    thread.start()
    try:
        if not wait_until_ready(port, thread):
            raise RuntimeError("The local editor server could not start")
        address = "http://127.0.0.1:" + str(port) + "/"
        print("[browser-fallback] local editor at " + address, file=sys.stderr,
              flush=True)
        opened = webbrowser.open(address, new=1)
        if not opened:
            print("[browser-fallback] The default browser did not confirm opening",
                  file=sys.stderr, flush=True)
        native_notice(
            "SkellyMotion is running in your default browser.\n\n"
            "Use the browser tab to edit your lyric videos. Your songs and AI "
            "model are unchanged.\n\n"
            "When you finish, close the browser tab and click OK here to stop "
            "the local SkellyMotion server."
        )
    finally:
        instance.should_exit = True
        thread.join(timeout=5)
    return 0

def main() -> int:
    freeze_support()
    home = configure()
    if "--version" in sys.argv:
        print("SkellyMotion 0.9.0")
        return 0
    if "--self-test" in sys.argv:
        return self_test()
    if "--ai-self-test" in sys.argv:
        try:
            return ai_self_test()
        except Exception as exc:
            print("Bundled AI engine self-test failed: " + repr(exc), file=sys.stderr)
            return 6
    if "--native-self-test" in sys.argv:
        try:
            return native_runtime_self_test()
        except Exception as exc:
            print("Native Python.NET/WebView2 self-test failed: " + repr(exc), file=sys.stderr)
            return 2
    if "--repair-runtime" in sys.argv:
        if not blocked_managed_assemblies():
            native_notice("No Windows download blocks were found on the bundled UI DLLs.\n"
                          "See desktop.log for other startup errors.")
            return 0
        if offer_download_marker_repair():
            native_notice("The selected SkellyMotion UI DLLs were unblocked.\n"
                          "Please relaunch SkellyMotion.exe.")
            return 0
        native_notice("Runtime repair was declined or could not complete.\n"
                      "No other files were modified.", error=True)
        return 3
    try:
        if "--browser-mode" in sys.argv:
            return run_browser_mode(home)
        return run_desktop(home, safe_mode="--safe-mode" in sys.argv,
                           smoke_test="--window-self-test" in sys.argv)
    except Exception as exc:
        print("Desktop startup error:", repr(exc), file=sys.stderr)
        native_error(
            desktop_runtime_error(exc)
            + "\nFor details see: " + str(home / "logs" / "desktop.log")
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
