# LyricForge consolidation and reliability audit — 2026-11-23

## Baselines and scope
- GitHub `skellyruno/LYRICFORGE`, draft PR #10, branch `fix/source-media-probe-20261123`.
- Last verified Windows release candidate: `0ff7725be5374f2d18f6809c00917ee6eac1e942` (250 tests and Windows/WebView2 verification from the preceding release gate).
- New shared consolidation commit: `417d32869282f4d2eb498596cc1723ca41e68c2e`. Exact commit CI pending at the time of this report.
- Larger WIP source baseline: `LYRICFORGE_WIP_UPDATED_2026-11-23_v2.zip`, SHA256 `44f0b72c48cca233df11b8074b9d8159b460471de810a37924b3b55f28d723c9`. It has additional modules/routes/UI tools absent from the GitHub release branch. Apply shared fixes to both; do not overwrite either tree with the other.

## Implemented
1. One atomic JSON publisher with unique sibling staging files and finally-cleanup for project manifests, recovery, render/post manifests, caches, presets, Brand Kit and B-roll indexes. No schema migration or dependency added.
2. Stream uploads into a private staging file, close before cleanup, and publish only successful nonempty transfers within size limits. Preserve previous bytes on stream interruption or rejection.
3. Unique draft and saved-project background staging. Validate before publishing, retire old images only after the new manifest is written. Locked old media no longer invalidates a successful replacement. Restrict old-background cleanup to known background names and extensions.
4. Stage Brand Kit media replacement before retiring existing assets. Missing Brand Kit/B-roll/preset reads do not create storage. Invalid JSON shapes use safe defaults, without silently rewriting them. B-roll index paths and invalid durations are excluded from playback/listing; unsafe references cannot drive deletion.
5. Consolidated output dimensions, background selection, encoder fallback, cache lookup and publication for full exports, previews and Shorts. Pending edits use the same background selection. Missing custom backgrounds fall back to a generated background. Larger WIP preserves cancellation behavior (no CPU retry after cancellation). Failed parent jobs stop stale child entries in GitHub; WIP already had this logic and now has a regression test.
6. Previously verified compact-screen native window geometry carried into WIP. Normal desktop size preserved. No redesign or replacement of WIP creative tools.
7. PR-only CI cancellation policy added to Linux and synchronized into WIP workflows; main, production, manual and tag builds are not cancelled by that policy.

## Verification
- Local final WIP: **83 targeted tests passed**, including failure injection, concurrent staging, upload/background preservation, invalid metadata, renderer cache, real media import and MP4 rendering, desktop geometry, authentication, project compatibility and cancellation.
- JavaScript: editor and autonomous UI smoke suites passed; syntax checks passed for app.js, autoclip.js and make.js.
- Python compilation passed for server, launcher and performance helper.
- Final WIP: **431 tests collected**. Separate broader run from the snapshot immediately before the last two extra regressions and cleanup guard was incomplete at report creation (139 passing progress markers, not a complete result). Final targeted run covers the last changes.
- GitHub exact new commit: [Linux CI](https://github.com/skellyruno/LYRICFORGE/actions/runs/45306131545), [Windows CI](https://github.com/skellyruno/LYRICFORGE/actions/runs/45306131438). Do not mark these passed until completed. Prior Windows artifact is not a binary of this new commit.
- Windows screenshot from earlier release gate verified the compact-size design; this WIP ZIP has not been rebuilt in Windows or visually inspected on a real desktop after this update. No mockup claimed as evidence.
- Local toolchain: Python 3.13.5, FFmpeg 7.1.5, Node 22.16.0. Media integration uses simulated ASR; real Whisper inference and human listening are not verified. No CPU or speed improvement claims.

## Remaining priorities / audit findings
| Priority | Area | Next verification |
|---|---|---|
| P0 | Release | Exact-commit Linux and Windows CI, packaged startup, real screenshot inspection. Keep draft PR unmerged until green. |
| P0 | User workflow | Real song import, actual Whisper, lyric editing, save/reopen, preview and final export, playback and DPI/resize on Windows. |
| P1 | Persistence | Atomic file replacement is not a multi-process transaction; independent read-modify-write operations may still need serialization. Test competing project edits and autosaves. |
| P1 | Asset cleanup | Retained locked backgrounds and failed-copy artifacts should be surfaced to an explicit maintenance action; do not delete user media automatically. |
| P1 | Consolidation | Inventory the larger WIP-only Make and creative features; port in focused, tested batches rather than replacing the release tree. |
| P2 | Performance | Benchmark long projects, CPU/GPU encoders, memory and export times with real media; then optimize measured hotspots. |
| P2 | UI | Capture each editor state and creative-tool panel at multiple DPI/desktop sizes; inspect actual screenshots, fix and recapture. |

## Preservation
Original WIP archive remains unchanged. All original archive paths retained; only listed source/workflow/test files updated, plus a new regression module and this audit. No generated workspace, test caches, dependency binaries or model data included. No merge or production release performed.
