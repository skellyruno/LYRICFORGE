"""Local Kokoro neural speech worker, isolated from the video encoder."""
import json,sys,wave,os
from pathlib import Path

def main():
    if len(sys.argv)!=4:raise ValueError('Expected model, voices and output directory')
    req=json.loads(sys.stdin.read(1024*1024+1));phrases=req['phrases'];voice=req['voice'];speed=float(req['speed'])
    if not isinstance(phrases,list) or not 1<=len(phrases)<=500 or any(not isinstance(t,str) or not 1<=len(t)<=1800 for t in phrases):raise ValueError('Invalid phrase list')
    if voice not in ('am_michael','am_adam','af_sarah') or not .70<=speed<=1.30:raise ValueError('Invalid neural voice')
    root=Path(sys.argv[3]);assert root.is_dir() and not root.is_symlink()
    import numpy as np
    from kokoro_onnx import Kokoro
    engine=Kokoro(sys.argv[1],sys.argv[2]);total=0.
    for i,phrase in enumerate(phrases):
        samples,rate=engine.create(phrase,voice=voice,speed=speed,lang='en-us');x=np.asarray(samples,dtype=np.float32)
        if x.ndim==2 and 1 in x.shape:x=x.reshape(-1)
        if x.ndim!=1 or not 8000<=rate<=48000 or not 0<x.size<=rate*50 or not np.isfinite(x).all():raise ValueError('Invalid neural audio')
        total+=x.size/rate
        if total>1800:raise ValueError('Narration exceeds 30 minutes')
        peak=float(np.max(np.abs(x)))
        if peak<1e-5:raise ValueError('Silent neural phrase')
        if peak>.98:x=x*(.98/peak)
        target=root/f'neural-{i:04d}.wav'
        if target.exists():raise ValueError('Refusing to overwrite neural output')
        with wave.open(str(target),'wb') as out:out.setparams((1,2,int(rate),0,'NONE','not compressed'));out.writeframes(np.rint(np.clip(x,-1,1)*32767).astype('<i2').tobytes())
    return 0
if __name__=='__main__':raise SystemExit(main())
