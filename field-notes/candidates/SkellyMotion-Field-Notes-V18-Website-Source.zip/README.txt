SKELLYMOTION — FIELD NOTES / VOL. 01

Static screening page. Upload index.html and media/ together to the desired directory on your website. The HTML has no remote dependencies, analytics, or autoplay; video loads on demand. Serve MP4 as video/mp4 and enable byte-range requests. The videos are H.264/AAC stereo, episodes 01–02: 1280x720; episodes 03–04: 960x540; all verified exact 60 fps. Episodes 01–03 are lossless clock-corrected remasters; episode 04 is the new V18 film. Original masters remain preserved. No website or channel has been published by this workflow.

For YouTube or another channel, upload the four MP4 files individually. Use the accompanying JPEG posters or select a frame. All four are music-led original educational shorts; not narrated. Review creative quality and verify permission to distribute the selected SoundFont's rendered audio before public release. Do not distribute the instrument bank itself. The example capture is a prior SkellyMotion production, not an external reference clip or live demo.

Titles and descriptions are embedded in index.html. Preserve older originals separately. No reference videos or private music are included.
